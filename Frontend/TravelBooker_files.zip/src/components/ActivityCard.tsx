import  React from 'react';

interface ActivityCardProps {
  title: string;
  location: string;
  price: number;
  image: string;
  category: string;
  userInitial: string;
  userBg: string;
  onViewDetails: () => void;
}

const ActivityCard: React.FC<ActivityCardProps> = ({
  title,
  location,
  price,
  image,
  category,
  userInitial,
  userBg,
  onViewDetails
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <img 
          src={image} 
          alt={title}
          className="w-full h-32 object-cover"
        />
        <div className={`absolute top-2 left-2 w-6 h-6 ${userBg} rounded-full flex items-center justify-center`}>
          <span className="text-white font-bold text-xs">{userInitial}</span>
        </div>
      </div>
      
      <div className="p-3">
        <h3 className="font-semibold text-sm mb-1">{title}</h3>
        <p className="text-xs text-gray-600 mb-2">{location}</p>
        <p className="text-xs text-gray-500 mb-3 line-clamp-2">
          Curated small-group experience. Certified guide. Safety first with gear included.
        </p>
        
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs text-gray-500">From </span>
            <span className="font-bold text-lg">₹{price}</span>
          </div>
          <button 
            onClick={onViewDetails}
            className="bg-yellow-400 text-xs font-semibold px-3 py-1 rounded hover:bg-yellow-500 transition"
          >
            View Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActivityCard;
 