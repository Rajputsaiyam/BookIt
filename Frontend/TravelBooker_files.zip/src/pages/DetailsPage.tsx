import  React, { useState } from 'react';
import Navbar from '../components/Navbar';
import { ArrowLeft } from 'lucide-react';

interface DetailsPageProps {
  onBack: () => void;
}

const DetailsPage: React.FC<DetailsPageProps> = ({ onBack }) => {
  const [selectedDate, setSelectedDate] = useState('Oct 22');
  const [selectedTime, setSelectedTime] = useState('07:00 am');
  const [quantity, setQuantity] = useState(1);

  const dates = ['Oct 22', 'Oct 23', 'Oct 24', 'Oct 25', 'Oct 26'];
  const times = ['07:00 am', '9:00 am', '11:00 am', '1:00 pm'];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto p-8">
        <button onClick={onBack} className="flex items-center mb-6 text-gray-600 hover:text-gray-800">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Details
        </button>

        <div className="flex gap-8">
          <div className="flex-1" style={{ width: '765px' }}>
            <img 
              src="https://images.unsplash.com/photo-1734438237000-d3a70f1e4e88?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxrYXlha2luZyUyMGFkdmVudHVyZSUyMG91dGRvb3IlMjBhY3Rpdml0eSUyMHdhdGVyJTIwc3BvcnRzfGVufDB8fHx8MTc2MTczMjM5NXww&ixlib=rb-4.1.0&fit=fillmax&h=381&w=765"
              alt="Kayaking"
              className="rounded-xl object-cover"
              style={{ width: '765px', height: '381px' }}
            />
          </div>

          <div className="bg-gray-100 rounded-xl p-6 flex flex-col gap-6" style={{ width: '387px', height: '303px' }}>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Starts at</span>
              <span className="text-lg font-bold">₹999</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Quantity</span>
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-6 h-6 bg-white rounded border flex items-center justify-center text-sm"
                >
                  -
                </button>
                <span className="text-lg font-bold">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-6 h-6 bg-white rounded border flex items-center justify-center text-sm"
                >
                  +
                </button>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Subtotal</span>
              <span className="text-lg font-bold">₹{999 * quantity}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Taxes</span>
              <span className="text-lg">₹69</span>
            </div>

            <hr className="border-gray-300" />

            <div className="flex justify-between items-center">
              <span className="text-lg font-bold">Total</span>
              <span className="text-xl font-bold">₹{(999 * quantity) + 69}</span>
            </div>

            <button className="w-full bg-gray-400 text-white py-2 rounded-lg text-sm">
              Confirm
            </button>
          </div>
        </div>

        <div className="mt-8" style={{ width: '765px' }}>
          <div className="bg-white rounded-xl p-8 space-y-8">
            <div>
              <h1 className="text-2xl font-bold mb-2">Kayaking</h1>
              <p className="text-gray-600 text-sm">
                Curated small-group experience. Certified guide. Safely first with gear included. Helmet and Life jackets along with an expert will accompany in kayaking.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Choose date</h3>
              <div className="flex gap-2">
                {dates.map((date) => (
                  <button
                    key={date}
                    onClick={() => setSelectedDate(date)}
                    className={`px-3 py-2 rounded text-sm ${
                      selectedDate === date 
                        ? 'bg-yellow-400 text-black font-semibold' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {date}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Choose time</h3>
              <div className="flex gap-2">
                {times.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`px-3 py-2 rounded text-sm ${
                      selectedTime === time 
                        ? 'bg-yellow-400 text-black font-semibold' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-2">All times are in IST (GMT +5:30)</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">About</h3>
              <p className="text-sm text-gray-600">
                Experience pristine, turquoise waters and whitest fishing. Minimum age 18.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailsPage;
 