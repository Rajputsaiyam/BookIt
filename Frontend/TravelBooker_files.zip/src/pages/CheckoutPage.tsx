import  React from 'react';
import { ArrowLeft, CreditCard, Lock } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface CheckoutPageProps {
  onNavigate: (page: string) => void;
}

const CheckoutPage: React.FC<CheckoutPageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-screen-xl mx-auto px-4 py-12">
        <button 
          onClick={() => onNavigate('details')}
          className="flex items-center space-x-2 text-primary mb-8 hover:text-accent transition"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Details</span>
        </button>

        <h1 className="text-4xl font-bold text-primary mb-12 text-center">Complete Your Booking</h1>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Booking Summary */}
          <div className="bg-white rounded-2xl p-8 shadow-lg h-fit">
            <h2 className="text-2xl font-bold mb-6">Booking Summary</h2>
            
            <div className="space-y-4 mb-6">
              <img 
                src="https://images.unsplash.com/photo-1760817137560-f4062758bed7?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBkZXN0aW5hdGlvbiUyMHRyb3BpY2FsJTIwYmVhY2glMjBwYXJhZGlzZXxlbnwwfHx8fDE3NjE3MzE4NDB8MA&ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200" 
                alt="Tropical Paradise"
                className="w-full h-48 object-cover rounded-xl"
              />
              
              <h3 className="text-xl font-semibold">Tropical Paradise</h3>
              
              <div className="space-y-2 text-gray-600">
                <div className="flex justify-between">
                  <span>Check-in:</span>
                  <span className="font-medium">Dec 15, 2024</span>
                </div>
                <div className="flex justify-between">
                  <span>Check-out:</span>
                  <span className="font-medium">Dec 22, 2024</span>
                </div>
                <div className="flex justify-between">
                  <span>Guests:</span>
                  <span className="font-medium">2 Adults</span>
                </div>
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span className="font-medium">7 nights</span>
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span>$299 × 7 nights</span>
                  <span>$2,093</span>
                </div>
                <div className="flex justify-between">
                  <span>Service fee</span>
                  <span>$150</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxes</span>
                  <span>$200</span>
                </div>
              </div>
              <div className="flex justify-between items-center font-bold text-xl border-t pt-4">
                <span>Total</span>
                <span className="text-primary">$2,443</span>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-2xl font-bold mb-6">Payment Details</h2>
            
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                  <input 
                    type="text" 
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="John"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                  <input 
                    type="text" 
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Doe"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input 
                  type="email" 
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="john.doe@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                <input 
                  type="tel" 
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="+1 (555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Card Number</label>
                <div className="relative">
                  <input 
                    type="text" 
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="1234 5678 9012 3456"
                  />
                  <CreditCard className="absolute right-3 top-3 w-5 h-5 text-gray-400" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Expiry Date</label>
                  <input 
                    type="text" 
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="MM/YY"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">CVV</label>
                  <input 
                    type="text" 
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="123"
                  />
                </div>
              </div>

              <button 
                onClick={() => onNavigate('confirmation')}
                type="button"
                className="w-full bg-gradient-to-r from-primary to-accent text-white py-4 rounded-xl font-semibold hover:shadow-lg transition flex items-center justify-center space-x-2"
              >
                <Lock className="w-5 h-5" />
                <span>Confirm Booking - $2,443</span>
              </button>
            </form>

            <div className="flex items-center justify-center space-x-4 mt-6 text-sm text-gray-500">
              <span>Secured by</span>
              <div className="flex space-x-2">
                <div className="bg-gray-100 px-3 py-1 rounded">VISA</div>
                <div className="bg-gray-100 px-3 py-1 rounded">MASTERCARD</div>
                <div className="bg-gray-100 px-3 py-1 rounded">PAYPAL</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default CheckoutPage;
 