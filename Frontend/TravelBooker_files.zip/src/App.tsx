import  React, { useState } from 'react';
import HomePage from './pages/HomePage';
import DetailsPage from './pages/DetailsPage';

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'details'>('home');
  const [selectedActivityId, setSelectedActivityId] = useState<number | null>(null);

  const handleViewDetails = (activityId: number) => {
    setSelectedActivityId(activityId);
    setCurrentPage('details');
  };

  const handleBack = () => {
    setCurrentPage('home');
    setSelectedActivityId(null);
  };

  return (
    <>
      {currentPage === 'home' && <HomePage onViewDetails={handleViewDetails} />}
      {currentPage === 'details' && <DetailsPage onBack={handleBack} />}
    </>
  );
}

export default App;
 